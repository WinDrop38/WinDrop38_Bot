
import logging
import random
import json
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

# Конфигурация
TOKEN = "7560765427:AAFz2_PKLc-IEOUEkhXuYcOs_fzmVwtTI3Y"
CHANNEL_USERNAME = "@WinDrop38"
MAX_PARTICIPANTS = 50
WINNERS_COUNT = 1
DATA_FILE = "participants.json"

# Логирование
logging.basicConfig(level=logging.INFO)

# Загрузка/сохранение участников
def load_participants():
    try:
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    except:
        return {}

def save_participants(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f)

# Команда /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[InlineKeyboardButton("🎉 Участвовать", callback_data="join")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Прими участие в розыгрыше! 🎁
Нажми кнопку ниже ⬇️", reply_markup=reply_markup)

# Обработка кнопки
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user

    try:
        member = await context.bot.get_chat_member(CHANNEL_USERNAME, user.id)
        if member.status in ("left", "kicked"):
            keyboard = [
                [InlineKeyboardButton("✅ Подписаться", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
                [InlineKeyboardButton("🔁 Проверить снова", callback_data="join")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "⚠️ Ты должен быть подписан на канал, чтобы участвовать:",
                reply_markup=reply_markup
            )
            return
    except:
        await query.edit_message_text("❌ Не удалось проверить подписку. Попробуй позже.")
        return

    participants = load_participants()
    if str(user.id) in participants:
        await query.edit_message_text("Ты уже участвуешь! 🎉")
        return

    if len(participants) >= MAX_PARTICIPANTS:
        await query.edit_message_text("⛔ Мест больше нет.")
        return

    participants[str(user.id)] = {
        "name": user.full_name,
        "username": user.username
    }
    save_participants(participants)
    await query.edit_message_text("✅ Ты участвуешь в розыгрыше! Удачи!")

# Команда /draw
async def draw(update: Update, context: ContextTypes.DEFAULT_TYPE):
    participants = load_participants()
    if not participants:
        await update.message.reply_text("❌ Нет участников.")
        return
    winners = random.sample(list(participants.values()), min(WINNERS_COUNT, len(participants)))
    result = "🎉 Победитель:
"
    for w in winners:
        tag = f"@{w['username']}" if w['username'] else w['name']
        result += f"🏆 {tag}
"
    await update.message.reply_text(result)

# Запуск
if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(CommandHandler("draw", draw))
    app.run_polling()
